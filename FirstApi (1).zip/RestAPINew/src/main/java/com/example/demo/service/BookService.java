package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dao.BookRepo;
import com.example.demo.entity.Book;

@Component
public class BookService {
	@Autowired
	  private BookRepo repo;
	/*
	 * private static List<Book> list = new ArrayList<>();
	 * 
	 * static {
	 * 
	 * list.add(new Book(1, "IT1", "kate1")); list.add(new Book(2, "IT2", "kate2"));
	 * list.add(new Book(3, "IT3", "kate3"));
	 * 
	 * 
	 * }
	 */
	public List<Book> getbook()
			{
		      
			List<Book> list=	(List<Book>) this.repo.findAll();
				return list;
			}
	public Book getbyid(int id)
	{
		Book book=null;
		try {
			//book=list.stream().filter(e->e.getId()==id).findFirst().get();
			book=this.repo.findById(id);
		} catch (Exception e2) {
			System.out.println("Not found id "+e2.getMessage());
		}
		
		
		return book;
		
	}
	public Book addBook(Book b)
	{
      Book result=repo.save(b);
		return result;
	}
    public void deleteBook(int bid)
    {
    //	list=list.stream().filter(book ->book.getId()!=bid).collect(Collectors.toList());
      repo.deleteById(bid);	
    }
    public void  updateBook(Book book , int bid)
    {
		/*
		 * list=list.stream().map(b-> { if(b.getId()==bid) {
		 * b.setTitle(book.getTitle()); b.setAuthor(book.getAuthor()); } return b; }
		 * ).collect(Collectors.toList());
		 */
    	book.setId(bid);
    	repo.save(book);
    }
}
