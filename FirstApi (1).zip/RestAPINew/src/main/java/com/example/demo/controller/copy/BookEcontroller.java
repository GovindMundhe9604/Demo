package com.example.demo.controller.copy;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Book;
import com.example.demo.service.BookService;



@RestController
public class BookEcontroller {
    private static final Book Null = null;
	@Autowired
//	private BookService bookservice;
    private BookService bookservice;
	
    @GetMapping("/books")
	public ResponseEntity<List<Book>> getBook()
	{
		List<Book> list=bookservice.getbook();
		if(list.size()<=0)
		{
			return  ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
		return ResponseEntity.of(Optional.of(list));
	}
	@GetMapping("/books/{id}")
	public ResponseEntity<Book> getbook(@PathVariable int  id)
	{
	   Book book=bookservice.getbyid(id);
	   if(book==Null)
	   {
		   return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	   }
		return ResponseEntity.of(Optional.of(book));
	}
	@PostMapping("/books")
	public ResponseEntity<Book> addbook(@RequestBody Book book )
	{
	  Book b=null;
	  try
	  {
		  b=this.bookservice.addBook(book);
		  System.out.println(book);
		  return ResponseEntity.of(Optional.of(b));
	  }catch (Exception e) {
		e.printStackTrace();
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	}
		
	}
	@DeleteMapping("books/{bookid}")
	public ResponseEntity<Void> deletebook(@PathVariable("bookid") int  bookid)
	{
		try {
			this.bookservice.deleteBook(bookid);
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
					
		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
		
		
		
	}
	@PutMapping("books/{bid}")
	public ResponseEntity<Book> updateBook(@RequestBody Book book ,@PathVariable("bid") int  bookid)
	{
		try {
			this.bookservice.updateBook(book, bookid);
			return ResponseEntity.ok().body(book);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	
		
		
	}
	
}
